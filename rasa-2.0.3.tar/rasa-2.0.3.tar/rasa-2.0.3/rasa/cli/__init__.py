import argparse

# skipcq:PYL-W0212
# noinspection PyProtectedMember
SubParsersAction = argparse._SubParsersAction
